"""汇总 18 次 train.py 实验 (6 激活 x 3 seed) 并绘图. 只读 runs/*/training_log.csv, 不做任何训练."""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import math
import numpy as np

ROOT = Path(".")
EXPS = {
    "sigmoid": ["runs/exp76", "runs/exp77", "runs/exp79"],
    "tanh": ["runs/exp80", "runs/exp82", "runs/exp83"],
    "arctan": ["runs/exp85", "runs/exp86", "runs/exp88"],
    "relu": ["runs/exp89", "runs/exp90", "runs/exp92"],
    "leaky_relu": ["runs/exp94", "runs/exp95", "runs/exp96"],
    "silu": ["runs/exp102", "runs/exp103", "runs/exp104"],
    "gelu": ["runs/exp124", "runs/exp125", "runs/exp126"],
    "soft_leaky_relu": ["runs/exp98", "runs/exp99", "runs/exp101"],
    "calu": ["runs/exp114", "runs/exp115", "runs/exp116"],
    "leaky_calu": ["runs/exp117", "runs/exp118", "runs/exp119"],
    "roclu": ["runs/exp121", "runs/exp122", "runs/exp123"],
}
ORDER = ["sigmoid", "tanh", "arctan", "relu", "leaky_relu", "silu", "gelu",
         "soft_leaky_relu", "calu", "leaky_calu", "roclu"]
CN = {"sigmoid": "Sigmoid", "tanh": "Tanh", "arctan": "Arctan",
      "relu": "ReLU", "leaky_relu": "Leaky ReLU", "silu": "SiLU",
      "gelu": "GELU",
      "soft_leaky_relu": "Soft Leaky ReLU", "calu": "CaLU",
      "leaky_calu": "Leaky CaLU", "roclu": "RoCLU"}
OUT = Path("experiments/activation_compare")
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({"font.size": 11, "axes.grid": True, "grid.alpha": 0.3,
                     "figure.dpi": 150, "savefig.bbox": "tight"})


def read_log(path):
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("epoch"):
                continue
            p = [x.strip() for x in line.split(",")]
            rows.append({"train_loss": float(p[1]), "train_acc": float(p[2]),
                         "val_loss": float(p[3]), "val_acc": float(p[4])})
    return rows


data = {a: [read_log(f"{e}/training_log.csv") for e in ds] for a, ds in EXPS.items()}
for a, runs in data.items():
    assert all(len(r) == 10 for r in runs), (a, [len(r) for r in runs])

# ---- 数值汇总 ----
print(f"{'activation':<16}{'best_val_acc (3 seeds)':<32}{'mean±std'}")
summary = {}
for a in ORDER:
    bests = np.array([max(r["val_acc"] for r in runs) for runs in data[a]])
    finals = np.array([runs[-1]["val_acc"] for runs in data[a]])
    summary[a] = {"bests": bests, "finals": finals,
                  "mean": float(bests.mean()), "std": float(bests.std(ddof=1))}
    print(f"{a:<16}{str([f'{b:.2f}' for b in bests]):<32}"
          f"{summary[a]['mean']:.2f}±{summary[a]['std']:.2f}")
print("\nLaTeX 行:")
for a in ORDER:
    print(f"{CN[a]} & {summary[a]['mean']:.2f} $\\pm$ {summary[a]['std']:.2f} \\\\")

EP = np.arange(1, 11)

# ---- 图1: val acc 曲线 (mean±std) ----
fig, ax = plt.subplots(figsize=(8, 5))
for a in ORDER:
    m = np.array([[r["val_acc"] for r in runs] for runs in data[a]])
    mean, std = m.mean(0), m.std(0, ddof=1)
    ax.plot(EP, mean, marker="o", ms=4, label=CN[a])
    ax.fill_between(EP, mean - std, mean + std, alpha=0.15)
ax.set_xlabel("Epoch")
ax.set_ylabel("Validation accuracy (%)")
ax.set_title("Validation accuracy vs epoch (mean±std over 3 seeds, MNIST test)")
ax.set_xticks(EP)
ax.legend()
fig.savefig(OUT / "fig1_val_acc_curves.png")
plt.close(fig)

# ---- 图1b: 去掉 Sigmoid 的放大版 (9 个非饱和/弱饱和激活的差距在此尺度下才可见) ----
ZOOM = [a for a in ORDER if a != "sigmoid"]
fig, ax = plt.subplots(figsize=(8, 5))
lo, hi = 100.0, 0.0
for a in ZOOM:
    m = np.array([[r["val_acc"] for r in runs] for runs in data[a]])
    mean, std = m.mean(0), m.std(0, ddof=1)
    ax.plot(EP, mean, marker="o", ms=4, label=CN[a])
    ax.fill_between(EP, mean - std, mean + std, alpha=0.15)
    lo, hi = min(lo, (mean - std).min()), max(hi, (mean + std).max())
ax.set_xlabel("Epoch")
ax.set_ylabel("Validation accuracy (%)")
ax.set_title("Validation accuracy vs epoch, sigmoid excluded (mean±std over 3 seeds)")
ax.set_xticks(EP)
ax.set_ylim(lo - 0.5, hi + 0.4)
ax.legend(ncol=2)
fig.savefig(OUT / "fig1b_val_acc_curves_no_sigmoid.png")
plt.close(fig)

# ---- 图2: train loss 曲线 ----
fig, ax = plt.subplots(figsize=(8, 5))
for a in ORDER:
    m = np.array([[r["train_loss"] for r in runs] for runs in data[a]])
    mean, std = m.mean(0), m.std(0, ddof=1)
    ax.plot(EP, mean, marker="o", ms=4, label=CN[a])
    ax.fill_between(EP, mean - std, mean + std, alpha=0.15)
ax.set_xlabel("Epoch")
ax.set_ylabel("Train loss (CrossEntropy, augmented train set)")
ax.set_title("Training loss vs epoch (mean±std over 3 seeds)")
ax.set_xticks(EP)
ax.legend(ncol=2)
fig.savefig(OUT / "fig2_train_loss_curves.png")
plt.close(fig)

# ---- 图3: 最终精度柱状图 (按均值降序排列) ----
fig, ax = plt.subplots(figsize=(9.5, 4.6))
SORTED = sorted(ORDER, key=lambda a: summary[a]["mean"], reverse=True)
means = [summary[a]["mean"] for a in SORTED]
stds = [summary[a]["std"] for a in SORTED]
xs = np.arange(len(SORTED))
ax.bar(xs, means, yerr=stds, capsize=5, color=[f"C{i % 10}" for i in range(len(SORTED))])
for i, (x, m, s) in enumerate(zip(xs, means, stds)):
    y = m + s + (0.12 if i % 2 == 0 else 0.42)
    ax.text(x, y, f"{m:.2f}±{s:.2f}", ha="center", fontsize=9)
ax.set_xticks(xs, [CN[a] for a in SORTED], rotation=20)
ax.set_ylabel("Best validation accuracy (%)")
ax.set_title("Final accuracy by activation (mean±std over 3 seeds, sorted)")
ax.set_ylim(min(means) - 3, max(means) + 2.0)
fig.savefig(OUT / "fig3_final_bar.png")
plt.close(fig)

# ---- 图4: 激活函数形状与导数 ----
x = np.linspace(-5, 5, 1001)
sig = 1 / (1 + np.exp(-x))
t = (np.arctan(x) / (np.pi / 2) + 1) / 2  # Cauchy CDF 门控
r = 1.444 * np.log(1.5 + np.arctan(x) / np.pi)  # RoCLU 门控 (k=1.444)
phi = np.array([0.5 * (1 + math.erf(v / math.sqrt(2))) for v in x])  # Gaussian CDF
funcs = {
    "Sigmoid": sig,
    "Tanh": np.tanh(x),
    "Arctan": np.arctan(x),
    "ReLU": np.maximum(x, 0),
    "Leaky ReLU (0.01)": np.where(x > 0, x, 0.01 * x),
    "SiLU": x * sig,
    "GELU": x * phi,
    "CaLU": x * t,
    "Soft Leaky ReLU (β=0.01)": 0.99 * x * sig + 0.01 * x,
    "Leaky CaLU (β=0.01)": 0.99 * x * t + 0.01 * x,
    "RoCLU (k=1.444)": x * r,
}
fig, axes = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
for name, y in funcs.items():
    axes[0].plot(x, y, label=name)
axes[0].set_ylabel("f(x)")
axes[0].set_title("Activation functions")
axes[0].legend(ncol=2, fontsize=9)
for name, y in funcs.items():
    dydx = np.gradient(y, x[1] - x[0])
    axes[1].plot(x, dydx, label=name)
axes[1].set_xlabel("x")
axes[1].set_ylabel("f'(x) (numeric)")
axes[1].set_title("Derivatives")
axes[1].legend(ncol=2, fontsize=9)
fig.savefig(OUT / "fig4_activations.png")
plt.close(fig)

# ---- .Epoch1 vs Epoch10 收敛速度表 ----
print("\nepoch1 -> epoch10 val_acc (mean):")
for a in ORDER:
    m = np.array([[r["val_acc"] for r in runs] for runs in data[a]])
    print(f"{a:<16} {m.mean(0)[0]:.2f} -> {m.mean(0)[-1]:.2f}")
print(f"\nfigures -> {OUT}")
