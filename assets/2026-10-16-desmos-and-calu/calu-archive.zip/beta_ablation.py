"""Beta 消融附录: soft leaky relu beta=0.01 (exp98/99/101) vs beta=0.2 (exp105/106/107)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

OUT = Path("experiments/activation_compare")
plt.rcParams.update({"font.size": 11, "axes.grid": True, "grid.alpha": 0.3,
                     "figure.dpi": 150, "savefig.bbox": "tight"})


def read_val_acc(exp):
    acc = []
    with open(f"{exp}/training_log.csv") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("epoch"):
                continue
            acc.append(float(line.split(",")[4]))
    return acc


groups = {"beta=0.01": ["runs/exp98", "runs/exp99", "runs/exp101"],
          "beta=0.1": ["runs/exp108", "runs/exp109", "runs/exp110"],
          "beta=0.2": ["runs/exp105", "runs/exp106", "runs/exp107"],
          "beta=0.3": ["runs/exp111", "runs/exp112", "runs/exp113"]}
EP = np.arange(1, 11)

print(f"{'beta':<10}{'bests':<28}{'mean±std':<14}{'epoch1 mean'}")
curves = {}
for name, exps in groups.items():
    runs = np.array([read_val_acc(e) for e in exps])
    assert runs.shape == (3, 10), (name, runs.shape)
    bests = runs.max(axis=1)
    curves[name] = runs
    print(f"{name:<10}{str([f'{b:.2f}' for b in bests]):<28}"
          f"{bests.mean():.2f}±{bests.std(ddof=1):.2f}   {runs[:, 0].mean():.2f}")

fig, ax = plt.subplots(figsize=(8, 5))
for name, runs in curves.items():
    mean, std = runs.mean(0), runs.std(0, ddof=1)
    ax.plot(EP, mean, marker="o", ms=4, label=f"Soft Leaky ReLU ({name})")
    ax.fill_between(EP, mean - std, mean + std, alpha=0.15)
ax.set_xlabel("Epoch")
ax.set_ylabel("Validation accuracy (%)")
ax.set_title("Beta ablation: Soft Leaky ReLU (mean±std over 3 seeds)")
ax.set_xticks(EP)
ax.legend()
fig.savefig(OUT / "fig5_beta_ablation.png")
plt.close(fig)
print("figure ->", OUT / "fig5_beta_ablation.png")
